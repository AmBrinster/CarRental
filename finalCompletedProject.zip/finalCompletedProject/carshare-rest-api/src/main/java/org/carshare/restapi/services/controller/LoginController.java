package org.carshare.restapi.services.controller;

import org.carshare.restapi.services.jparepositories.LoginRepository;
import org.carshare.restapi.services.modell.Users;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;



@RestController
public class LoginController {
    @Autowired
    LoginRepository loginRepository;

    @GetMapping("/login")
    public ResponseEntity<Users> validateCredentials(@RequestParam String email, @RequestParam String password) {
        Users user = loginRepository.findByEmailAndPassword(email, password);
        return user != null ? new ResponseEntity<>(user, HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND);


    }

}
