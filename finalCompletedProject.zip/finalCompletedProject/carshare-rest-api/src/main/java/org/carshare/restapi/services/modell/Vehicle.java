package org.carshare.restapi.services.modell;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import javax.persistence.*;

@Entity
public class Vehicle {
    @Id
    private String vehicleCode;
    private String vehicleType;
    private String vehicleName;
    private int noOfSeats;
    private boolean airBagSafety;
    private boolean gpsEnabled;

    @JsonIgnore
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "location_code")
    private Location location;

    public Vehicle() {
    }

    public String getVehicleCode() {
        return vehicleCode;
    }

    public void setVehicleCode(String vehicleCode) {
        this.vehicleCode = vehicleCode;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getVehicleName() {
        return vehicleName;
    }

    public void setVehicleName(String vehicleName) {
        this.vehicleName = vehicleName;
    }

    public int getNoOfSeats() {
        return noOfSeats;
    }

    public void setNoOfSeats(int noOfSeats) {
        this.noOfSeats = noOfSeats;
    }

    public boolean isAirBagSafety() {
        return airBagSafety;
    }

    public void setAirBagSafety(boolean airBagSafety) {
        this.airBagSafety = airBagSafety;
    }

    public boolean isGpsEnabled() {
        return gpsEnabled;
    }

    public void setGpsEnabled(boolean gpsEnabled) {
        this.gpsEnabled = gpsEnabled;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    /*@Override
    public String toString() {
        return "Vehicle{" +
                "vehicleCode='" + vehicleCode + '\'' +
                ", vehicleType='" + vehicleType + '\'' +
                ", vehicleName='" + vehicleName + '\'' +
                ", noOfSeats=" + noOfSeats +
                ", airBagSafety=" + airBagSafety +
                ", gpsEnabled=" + gpsEnabled +
                ", location=" + location +
                '}';
    }*/
}
