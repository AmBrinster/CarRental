package org.carshare.restapi.services.controller;

import org.carshare.restapi.services.jparepositories.LocationRepository;
import org.carshare.restapi.services.modell.Location;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class LocationController {
    Logger log = LoggerFactory.getLogger(this.getClass());

    @Autowired
    LocationRepository locationRepository;
    @GetMapping("/getAllLocations")
    public ResponseEntity<List<Location>> getAllLocations(){
        List<Location> allLocationList = locationRepository.findAll();
        HttpHeaders headers = new HttpHeaders();
        headers.add("Access-Control-Allow-Origin","*");
        //log.info("Returned Location List - {}",allLocationList);
        return new ResponseEntity<>(allLocationList,headers,HttpStatus.OK);
    }

}
