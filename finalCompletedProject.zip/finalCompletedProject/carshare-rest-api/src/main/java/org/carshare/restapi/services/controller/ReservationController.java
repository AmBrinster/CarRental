package org.carshare.restapi.services.controller;

import org.carshare.restapi.services.jparepositories.ReservationRepository;
import org.carshare.restapi.services.modell.Reservation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Date;
import java.util.List;
import java.util.Random;

@RestController
@RequestMapping("/reservation")
public class ReservationController {
    Logger log = LoggerFactory.getLogger(this.getClass());
    @Autowired
    ReservationRepository reservationRepository;

    @GetMapping("/fetchAllReservations")
    public ResponseEntity<List<Reservation>> getAllReservations() {
        List<Reservation> allReservationDetailsList = reservationRepository.findAll();
        HttpHeaders headers = new HttpHeaders();
        headers.add("Access-Control-Allow-Origin","*");
        return (allReservationDetailsList.size() != 0 ? new ResponseEntity<>(allReservationDetailsList,headers, HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND));
    }

    @PostMapping("/makeReservation")
    public ResponseEntity<Reservation> makeAReservation(@Valid @RequestBody Reservation reservation) {
        log.info("Inside makeAReservation ---->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> {}",reservation);

        Reservation savedReservation = reservationRepository.save(reservation);
        log.info("Inside makeAReservation saved Data {}",savedReservation);
        return (savedReservation != null ? new ResponseEntity(savedReservation,HttpStatus.CREATED) : new ResponseEntity(HttpStatus.BAD_REQUEST));
    }

    @GetMapping("/getAllReservationsForaUser")
    public ResponseEntity<List<Reservation>> getAllReservationForaUser(@RequestParam String email) {
        List<Reservation> byCustomer_email = reservationRepository.findByCustomer_Email(email);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Access-Control-Allow-Origin","*");
        return (byCustomer_email.size() != 0 ? new ResponseEntity<>(byCustomer_email,headers, HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND));

    }

    @GetMapping("/findUpcomingReservationsForaUser")
    public ResponseEntity<List<Reservation>> findUpcomingReservationsForaUser(@RequestParam String email) {
        List<Reservation> upComingReservations = reservationRepository.findByCustomer_EmailAndPickUpTimeAfter(email,new Date());
        HttpHeaders headers = new HttpHeaders();
        headers.add("Access-Control-Allow-Origin","*");
        return (upComingReservations.size() != 0 ? new ResponseEntity<>(upComingReservations,headers, HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND));

    }

    @GetMapping("/findPastReservationsForaUser")
    public ResponseEntity<List<Reservation>> findPastReservationsForaUser(@RequestParam String email) {
        List<Reservation> pastReservations = reservationRepository.findByCustomer_EmailAndDropTimeBefore(email,new Date());
        HttpHeaders headers = new HttpHeaders();
        headers.add("Access-Control-Allow-Origin","*");
        return (pastReservations.size() != 0 ? new ResponseEntity<>(pastReservations, headers,HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND));

    }
    @GetMapping("/findReservationByConfirmatioNumber")
    public ResponseEntity<List<Reservation>> findReservationByConfirmatioNumber(@RequestParam String confNumber) {
        List<Reservation> reservationList = reservationRepository.findByReservationConfirmationNumber(confNumber);
        HttpHeaders headers = new HttpHeaders();
        headers.add("Access-Control-Allow-Origin","*");
        return (reservationList.size() != 0 ? new ResponseEntity<>(reservationList, headers,HttpStatus.OK) : new ResponseEntity<>(HttpStatus.NOT_FOUND));

    }



}
