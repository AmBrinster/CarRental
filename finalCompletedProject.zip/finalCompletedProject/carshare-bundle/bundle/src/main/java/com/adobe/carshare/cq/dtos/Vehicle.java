package com.adobe.carshare.cq.dtos;



public class Vehicle {

    private String vehicleCode;
    private String vehicleType;
    private String vehicleName;
    private int noOfSeats;
    private boolean airBagSafety;
    private boolean gpsEnabled;

    public Vehicle() {
    }

    public String getVehicleCode() {
        return vehicleCode;
    }

    public void setVehicleCode(String vehicleCode) {
        this.vehicleCode = vehicleCode;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getVehicleName() {
        return vehicleName;
    }

    public void setVehicleName(String vehicleName) {
        this.vehicleName = vehicleName;
    }

    public int getNoOfSeats() {
        return noOfSeats;
    }

    public void setNoOfSeats(int noOfSeats) {
        this.noOfSeats = noOfSeats;
    }

    public boolean isAirBagSafety() {
        return airBagSafety;
    }

    public void setAirBagSafety(boolean airBagSafety) {
        this.airBagSafety = airBagSafety;
    }

    public boolean isGpsEnabled() {
        return gpsEnabled;
    }

    public void setGpsEnabled(boolean gpsEnabled) {
        this.gpsEnabled = gpsEnabled;
    }

    @Override
    public String toString() {
        return "Vehicle{" +
                "vehicleCode='" + vehicleCode + '\'' +
                ", vehicleType='" + vehicleType + '\'' +
                ", vehicleName='" + vehicleName + '\'' +
                ", noOfSeats=" + noOfSeats +
                ", airBagSafety=" + airBagSafety +
                ", gpsEnabled=" + gpsEnabled +
                '}';
    }
}
