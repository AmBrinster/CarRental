package com.adobe.carshare.cq.services;

import com.adobe.carshare.cq.dtos.Reservation;

/**
 * Created by 298625 on 4/9/2019.
 */
public interface MakeReservation {
    String reserveVehicle(Reservation reservation);
}
