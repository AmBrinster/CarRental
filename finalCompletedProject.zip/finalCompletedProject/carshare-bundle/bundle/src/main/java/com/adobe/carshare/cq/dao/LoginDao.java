package com.adobe.carshare.cq.dao;

import com.adobe.carshare.cq.RestExchangeUtility;
import com.adobe.carshare.cq.impl.RestExchangeUtilityImpl;

public class LoginDao {
    RestExchangeUtility restExchangeUtility = new RestExchangeUtilityImpl();
    public String validateLogin(String email,String password){
        final String LOGIN_SERVICE_URL=String.format("http://localhost:8080/login?email=%s&password=%s",email,password);
        String responseMsg = restExchangeUtility.makeAGetCall(LOGIN_SERVICE_URL);
        return responseMsg;

    }
}
