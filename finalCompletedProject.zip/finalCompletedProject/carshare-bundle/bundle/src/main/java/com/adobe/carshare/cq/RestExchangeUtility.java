package com.adobe.carshare.cq;

import java.io.IOException;

public interface RestExchangeUtility {
    public String makeAGetCall(String url);
    public String makeApostCall(String url, Object payLoad) throws IOException;
}
