package com.adobe.carshare.cq.services;

import com.adobe.carshare.cq.dao.MakeReservationDao;
import com.adobe.carshare.cq.dtos.Reservation;

/**
 * Created by 298625 on 4/9/2019.
 */
public class MakeReservationImpl implements MakeReservation {

    public String reserveVehicle(Reservation reservation) {
        MakeReservationDao makeReservationDao = new MakeReservationDao();
        String responseMsg = makeReservationDao.reserveVehicle(reservation);
        return responseMsg;
    }
}
