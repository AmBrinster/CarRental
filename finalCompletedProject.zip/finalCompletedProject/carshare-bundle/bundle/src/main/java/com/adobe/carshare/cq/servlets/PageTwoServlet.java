package com.adobe.carshare.cq.servlets;

import com.adobe.carshare.cq.dtos.Location;
import com.adobe.carshare.cq.dtos.RatePlan;
import com.adobe.carshare.cq.dtos.Reservation;
import com.adobe.carshare.cq.dtos.Vehicle;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@SlingServlet(paths = "/bin/savePageTwo")
public class PageTwoServlet extends SlingSafeMethodsServlet {
    Logger log = LoggerFactory.getLogger(this.getClass());

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException {
        String[] vehicleData = request.getParameter("selectedVehicleRowData").split("~");
        String[] ratePlanData = request.getParameter("selectedRatePlanData").split("~");
       /* HttpSession session = request.getSession();
        //log.info("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX - {} "+request.getAttribute("reservationPageOne"));
        Vehicle vehicle = new Vehicle();
        vehicle.setVehicleCode(vehicleData[0]);
        vehicle.setVehicleType(vehicleData[1]);
        vehicle.setVehicleName(vehicleData[2]);
        vehicle.setNoOfSeats(Integer.parseInt(vehicleData[3]));
        vehicle.setAirBagSafety(Boolean.valueOf(vehicleData[4]));
        vehicle.setGpsEnabled(Boolean.valueOf(vehicleData[5]));

        log.info("Vehicle - {} "+vehicle);



        RatePlan ratePlan =new RatePlan();
        ratePlan.setRateCode(ratePlanData[0]);
        ratePlan.setRatePlanName(ratePlanData[1]);
        ratePlan.setCurrency(ratePlanData[2]);
        ratePlan.setHourlyRate(Long.parseLong(ratePlanData[3]));
        //ratePlan.setLocation(currentLocationObj);
        ratePlan.setVehicle(vehicle);*/
        RequestDispatcher rd = request.getRequestDispatcher("/content/carshare-app/registrationlanding/renterinfo.html");
        log.info("Before forwarding to renter info");
        rd.forward(request,response);

    }
}
