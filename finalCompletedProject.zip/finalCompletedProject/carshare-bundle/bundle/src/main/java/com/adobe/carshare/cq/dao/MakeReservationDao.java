package com.adobe.carshare.cq.dao;

import com.adobe.carshare.cq.RestExchangeUtility;
import com.adobe.carshare.cq.dtos.Reservation;
import com.adobe.carshare.cq.impl.RestExchangeUtilityImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

/**
 * Created by 298625 on 4/9/2019.
 */
public class MakeReservationDao {
    Logger log = LoggerFactory.getLogger(this.getClass());

    RestExchangeUtility restExchangeUtility = new RestExchangeUtilityImpl();
    public String reserveVehicle(Reservation reservation) {
        log.info("Inside MakeReservationDao");
        String response ="";
        try {
            response =restExchangeUtility.makeApostCall("http://localhost:8080/reservation/makeReservation",reservation);
            log.info("response is  {}",response);
        } catch (IOException e) {

        }

        return response;
    }
}
