$(document).ready(function(){

    
    $("#submit_btn").click(function(e){ 
        e.preventDefault();
        var formdata = $("#reg_form").serialize();
        var data = "materialRegisterFormFirstName="+document.getElementById("materialRegisterFormFirstName").value+"&materialRegisterFormLastName="+document.getElementById("materialRegisterFormLastName").value+"&materialRegisterFormEmail="+document.getElementById("materialRegisterFormEmail").value+"&materialRegisterFormPassword="+document.getElementById("materialRegisterFormPassword").value+"&materialRegisterFormPhone="+document.getElementById("materialRegisterFormPhone").value;
        
        
        $.ajax({
            url: '/bin/customservlet',
            type: 'post',
            data: formdata,
            success: function( data, textStatus, jQxhr ){
                
                
                window.location.href = 'http://localhost:4502/content/abav-car-share/en/login.html';
                
                
            },
            error: function( jqXhr, textStatus, errorThrown ){
                
                window.location.href = 'http://localhost:4502/content/abav-car-share/en/register.html?errMsg=Registration failed';
            }
        });
    });
    

});