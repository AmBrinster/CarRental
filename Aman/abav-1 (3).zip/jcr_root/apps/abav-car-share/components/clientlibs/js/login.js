$("#login_submit").click(function(e){ 
    
    var responseMsg="";
    e.preventDefault();
    var logindata= $("#login_form").serialize();
    
    
    $.ajax({
        url: '/content/abav-car-share/en/dummy.html',
        type: 'get',
        data: logindata,
        success: function( data, textStatus, jQxhr ){
            responseMsg =data;
            if(responseMsg.includes("firstName")){
                window.location.href = 'http://localhost:4502/content/abav-car-share/en.html';
            }
            else{                
                window.location.href = 'http://localhost:4502/content/abav-car-share/en/login.html?errMsg=Username/Password Invalid';
            }   
        },
        error: function( jqXhr, textStatus, errorThrown ){
            
            window.location.href = 'http://localhost:4502/content/abav-car-share/en/login.html?errMsg='+errorThrown;
        }
    });
});