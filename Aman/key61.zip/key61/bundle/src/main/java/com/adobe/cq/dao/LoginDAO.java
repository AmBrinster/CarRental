package com.adobe.cq.dao;

import com.adobe.cq.models.Login;
import com.adobe.cq.models.Registration;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class LoginDAO {
    Logger log = LoggerFactory.getLogger(this.getClass());

    public  String callLoginService(Login login) throws ClientProtocolException, IOException {
        log.info("Inside   callLoginService with {} , {}",login.getEmail(),login.getPassword());
        CloseableHttpClient client = HttpClients.createDefault();
        HttpGet httpGet = new HttpGet("http://localhost:8080/registration/login?email="+login.getEmail()+"&password="+login.getPassword());
        httpGet.setHeader("Accept", "application/json");
        httpGet.setHeader("Content-type", "application/json");
        log.info("Inside   callLoginService before callingg execute");
        CloseableHttpResponse response = client.execute(httpGet);
        log.info("Inside   callLoginService after callingg execute");
        int status = response.getStatusLine().getStatusCode();
        log.info("status --{}",status);
        BufferedReader reader = new BufferedReader(new InputStreamReader(
                response.getEntity().getContent()));

        String inputLine;
        StringBuffer responseString = new StringBuffer();
        log.info("Inside   callLoginService before reading response");
        while ((inputLine = reader.readLine()) != null) {
            responseString.append(inputLine);
        }
        log.info("Inside   callLoginService after reading response");
        reader.close();

        // print result

        log.info("content --{}",responseString);
        client.close();
        return responseString.toString();


    }

}
