package com.adobe.cq;

import com.adobe.cq.impl.LoginServiceImpl;
import com.adobe.cq.models.Login;
import com.adobe.cq.models.Registration;
import org.apache.felix.scr.annotations.sling.SlingServlet;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.SlingHttpServletResponse;
import org.apache.sling.api.servlets.SlingSafeMethodsServlet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.servlet.ServletException;
import java.io.IOException;

@SlingServlet(resourceTypes = "service/getLoginDetails",
        extensions = "html",
        methods = "GET",
        metatype = true)
public class LoginServlet extends SlingSafeMethodsServlet {
    Logger log = LoggerFactory.getLogger(this.getClass());
    LoginService loginService = new LoginServiceImpl();

    @Override
    protected void doGet(SlingHttpServletRequest request, SlingHttpServletResponse response) throws ServletException, IOException{
        log.info("Login Servlet !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! doGet22");
        String result = "";
        Login login = new Login();
        login.setEmail( request.getParameter("materialLoginFormEmail"));
        login.setPassword( request.getParameter("materialLoginFormPassword"));
        log.info("Calling  userLogin with {} , {}",login.getEmail(),login.getPassword());
        try {
            result = loginService.userLogin(login);
            response.getWriter().println(result);
        }catch (Exception ex){
            log.error("Exception while calling userLogin - {}",ex.getMessage());
        }
    }
}
