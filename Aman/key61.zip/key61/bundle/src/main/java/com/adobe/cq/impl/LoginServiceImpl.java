package com.adobe.cq.impl;

import com.adobe.cq.LoginService;
import com.adobe.cq.dao.LoginDAO;
import com.adobe.cq.dao.RegistrationDAO;
import com.adobe.cq.models.Login;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LoginServiceImpl implements LoginService {
    Logger log = LoggerFactory.getLogger(this.getClass());
    LoginDAO loginDAO = new LoginDAO();

    @Override
    public String userLogin(Login login) throws Exception {
        log.info("Inside   userLogin with {} , {}",login.getEmail(),login.getPassword());
        return loginDAO.callLoginService(login);

    }
}
