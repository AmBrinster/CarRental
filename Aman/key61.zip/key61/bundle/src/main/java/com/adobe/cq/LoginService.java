package com.adobe.cq;

import com.adobe.cq.models.Login;

public interface LoginService {
    String userLogin(Login login) throws Exception;
}
