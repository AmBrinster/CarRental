package com.cognizant.am_brinster.easynotes.controller;

import com.cognizant.am_brinster.easynotes.entity.User;
import com.cognizant.am_brinster.easynotes.repository.RegistrationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/registration")
public class RegistrationController {

    @Autowired
    RegistrationRepository registrationRepository;

    @PostMapping("/users")
    public User createUser(@Valid @RequestBody User user){
        return registrationRepository.save(user);
    }

    @GetMapping("/login")
    public User login(@RequestParam String email,@RequestParam String password){
        return registrationRepository.findByEmailAndPassword(email,password);
    }

}
